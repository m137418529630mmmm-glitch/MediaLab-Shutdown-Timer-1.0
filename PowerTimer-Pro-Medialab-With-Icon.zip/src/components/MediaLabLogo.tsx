import React from 'react';

interface MediaLabLogoProps {
  className?: string;
}

export const MediaLabLogo: React.FC<MediaLabLogoProps> = ({ className = '' }) => {
  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      <img
        src="/medialab-logo.png"
        alt="mediaLab publishing"
        className="h-12 sm:h-14 w-auto object-contain pointer-events-none"
        draggable={false}
      />
    </div>
  );
};
