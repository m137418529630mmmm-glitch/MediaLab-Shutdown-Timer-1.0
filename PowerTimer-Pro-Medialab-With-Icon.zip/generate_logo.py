import subprocess
import os

DEMI_FONT = "/usr/share/fonts/opentype/urw-base35/URWGothic-Demi.otf"
BOOK_FONT = "/usr/share/fonts/opentype/urw-base35/URWGothic-Book.otf"

# 1. Render Line 1: medıaLab
# x-size ~ 357, y-size ~ 75
subprocess.check_call([
    "convert",
    "-background", "none",
    "-fill", "#000000",
    "-font", DEMI_FONT,
    "-pointsize", "72",
    "label:medıaLab",
    "/tmp/line1_raw.png"
])

# Exact coordinates computed:
# stem of 'ı': x=165..175, center=170, top=14
# Red play triangle ▶
# Let's draw the triangle: left vertical edge at x=163, apex pointing right at x=179
# y range: 0 to 12, center y=6
# So triangle points: (163, 0) (179, 6) (163, 12)
subprocess.check_call([
    "convert",
    "/tmp/line1_raw.png",
    "-fill", "#d63f24",
    "-draw", "polygon 164,0 179,6 164,12",
    "/tmp/line1_final.png"
])

# 2. Render Line 2: publishing
subprocess.check_call([
    "convert",
    "-background", "none",
    "-fill", "#000000",
    "-font", BOOK_FONT,
    "-pointsize", "52",
    "label:publishing",
    "/tmp/line2_raw.png"
])

# Concentric target inside bowl of 'p':
# center is (20.5, 24.5)
# Bowl outer radius is ~12.5
# Ring 1: white ring gap r=8..10
# Ring 2: black ring r=5..7
# Ring 3: white center r=2.5
subprocess.check_call([
    "convert",
    "/tmp/line2_raw.png",
    "-fill", "none",
    "-stroke", "#f4f2ee",
    "-strokewidth", "2.8",
    "-draw", "circle 20.5,24.5 20.5,33",
    "-stroke", "#000000",
    "-strokewidth", "1.8",
    "-draw", "circle 20.5,24.5 20.5,30",
    "-stroke", "none",
    "-fill", "#f4f2ee",
    "-draw", "circle 20.5,24.5 20.5,27",
    "/tmp/line2_final.png"
])

# 3. Stack Line 1 and Line 2
os.makedirs("public", exist_ok=True)
subprocess.check_call([
    "convert",
    "-background", "none",
    "/tmp/line1_final.png",
    "-page", "+0+0",
    "/tmp/line2_final.png",
    "-page", "+0+62",
    "-layers", "merge",
    "-trim",
    "+repage",
    "-bordercolor", "none",
    "-border", "4",
    "public/medialab-logo.png"
])

print("Logo generation complete!")
subprocess.check_call(["identify", "public/medialab-logo.png"])
